﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

[TestClass]
public class FigureTests
{
	[TestMethod]
	public void PerimeterCalculator_CorrectValues_ReturnsPerimeter()
	{
		var p1 = new Point(0, 0);
		var p2 = new Point(0, 3);
		var p3 = new Point(4, 3);
		var p4 = new Point(4, 0);
		var figure = new Figure(p1, p2, p3, p4);

		Assert.AreEqual(14, figure.PerimeterCalculator());
	}
}