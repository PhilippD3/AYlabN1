﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

[TestClass]
public class RectangleTests
{
    [TestMethod]
    public void CalculateArea_CorrectValues_ReturnsArea()
    {
        var rectangle = new Rectangle(5, 10);
        Assert.AreEqual(50, rectangle.Area);
    }

    [TestMethod]
    public void CalculatePerimeter_CorrectValues_ReturnsPerimeter()
    {
        var rectangle = new Rectangle(5, 10);
        Assert.AreEqual(30, rectangle.Perimeter);
    }
}
