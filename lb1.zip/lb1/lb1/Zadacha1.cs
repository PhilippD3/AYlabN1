﻿using System;

class Zadacha1
{
    static void Main()
    {
        Console.WriteLine("Тип данных: byte");
        Console.WriteLine($"Минимальное значение: {byte.MinValue}");
        Console.WriteLine($"Максимальное значение: {byte.MaxValue}");

        Console.WriteLine("Тип данных: short");
        Console.WriteLine($"Минимальное значение: {short.MinValue}");
        Console.WriteLine($"Максимальное значение: {short.MaxValue}");

        Console.WriteLine("Тип данных: int");
        Console.WriteLine($"Минимальное значение: {int.MinValue}");
        Console.WriteLine($"Максимальное значение: {int.MaxValue}");

        Console.WriteLine("Тип данных: long");
        Console.WriteLine($"Минимальное значение: {long.MinValue}");
        Console.WriteLine($"Максимальное значение: {long.MaxValue}");

        Console.WriteLine("Тип данных: float");
        Console.WriteLine($"Минимальное значение: {float.MinValue}");
        Console.WriteLine($"Максимальное значение: {float.MaxValue}");

        Console.WriteLine("Тип данных: double");
        Console.WriteLine($"Минимальное значение: {double.MinValue}");
        Console.WriteLine($"Максимальное значение: {double.MaxValue}");
    }
}
